﻿using System.Web.UI;

namespace edc_tpf.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}