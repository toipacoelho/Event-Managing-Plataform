﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(edc_tpf.Startup))]
namespace edc_tpf
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
