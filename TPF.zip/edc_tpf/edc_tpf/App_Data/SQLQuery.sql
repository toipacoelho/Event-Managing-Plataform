﻿DROP XML SCHEMA COLLECTION [dbo].[EventSchema]

CREATE XML SCHEMA COLLECTION [dbo].[EventSchema] As
N'
<xs:schema attributeFormDefault="unqualified" elementFormDefault="qualified" xmlns:xs="http://www.w3.org/2001/XMLSchema">
  <xs:element name="events">
    <xs:complexType>
      <xs:sequence>
        <xs:element maxOccurs="unbounded" name="event">
          <xs:complexType>
            <xs:sequence>
              <xs:element name="name" type="xs:string" />
              <xs:element name="datetime" type="xs:string" />
              <xs:element name="location" type="xs:string" />
              <xs:element name="description" type="xs:string" />
              <xs:element name="creator" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>
'

DROP TABLE [dbo].[EventsSet]

CREATE TABLE [dbo].[EventsSet] (
    [Id] int IDENTITY(1,1) NOT NULL,
	[xmlEvent] [xml](Document [dbo].[EventSchema])
);
