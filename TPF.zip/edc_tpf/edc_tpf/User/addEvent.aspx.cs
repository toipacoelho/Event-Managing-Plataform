﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Xml;
using System.Data.SqlClient;
using System.Web;
using Subgurim.Controles;
using System.Web.Services;

namespace edc_tpf
{
    public partial class addEvent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DateTime today = DateTime.Today;
            DateTime now = DateTime.UtcNow;
            date.Value = today.Day + "-" + today.Month + "-" + today.Year;
            hour.Value = now.Hour + ":" + now.Minute;

            //GMap1.Add(new GMapUI());

            //GMapUIOptions options = new GMapUIOptions();
            //options.maptypes_hybrid = false;
            //options.keyboard = false;
            //options.maptypes_physical = false;
            //options.zoom_scrollwheel = false;



        }

        protected void Unnamed1_Click(object sender, EventArgs e)
        {
            //cancel
        }

        protected void Unnamed2_Click(object sender, EventArgs e)
        {
            //submit
            XmlDocument xdoc = eventList.GetXmlDocument();

            XmlElement events = xdoc.SelectSingleNode("events") as XmlElement;
            XmlElement evento = xdoc.CreateElement("event");
            XmlElement name = xdoc.CreateElement("name");
            XmlElement datetime = xdoc.CreateElement("datetime");
            XmlElement location = xdoc.CreateElement("location");
            XmlElement desc = xdoc.CreateElement("description");
            XmlElement creator = xdoc.CreateElement("creator");

            name.InnerText = this.name.Value;
            datetime.InnerText = date.Value + hour.Value;
            location.InnerText = searchBox.Value;
            desc.InnerText = this.desc.Value;
            creator.InnerText = HttpContext.Current.User.Identity.Name;

            events?.AppendChild(evento);
            evento.AppendChild(name);
            evento.AppendChild(datetime);
            evento.AppendChild(location);
            evento.AppendChild(desc);
            evento.AppendChild(creator);

            eventList.Save();
        }
    }

}

